# Start with our base settings
from .settings import *

# Copy our working DB to /tmp..